import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import cors from "cors";

import DepartmentRouter from "./department/department.route.js";
import UserRouter from "./admin/user.route.js";


dotenv.config();

mongoose
  .connect(process.env.DB_URL)
  .then(() => console.log("✅ DB Connected Successfully..."))
  .catch((err) => console.log("❌ DB failed to connect:", err.message));

const app = express();

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use((req, res, next) => {
  console.log(`➡️ ${req.method} ${req.originalUrl}`);
  next();
});




app.use("/auth",UserRouter);

app.use("/department",DepartmentRouter)

app.listen(4040, () => console.log("🚀 Server running on port 4040"));
